# Thinkly for OpenClaw

Your best AI work should not die in thread history.

Thinkly turns AI chats into a reusable wiki and knowledge graph.
Save useful OpenClaw exchanges, notes, URLs, and files into Thinkly, and it keeps
turning them into connected pages, topic wikis, and reusable context you can build on.
The point is not saving more clips. The point is giving your best AI work a structure
that compounds instead of disappearing into chat history.

## What it does

- Save useful OpenClaw exchanges with `/clip`
- Save a specific line when only part of the conversation matters
- Collect text, URLs, and files with `/ingest`
- Turn saved material into connected pages, topic wikis, and reusable knowledge in Thinkly

## Why power users install it

- AI chats stop living as isolated threads and start becoming a reusable knowledge base
- reviewed inputs can keep compounding into pages, briefs, and topic structures
- you get the upside of a wiki and graph workflow without building a DIY stack first

## What Thinkly builds from your inputs

- reusable clips you can keep and reference later
- pages that gather related context in one place
- topic wikis that keep growing as more material comes in
- a knowledge graph that keeps related material connected instead of scattered

## Required config

```json
{
  "apiUrl": "https://thinkly.pluglab.ai",
  "apiKey": "tk_your_api_key"
}
```

Optional advanced config:

```json
{
  "apiUrl": "https://thinkly.pluglab.ai",
  "apiKey": "tk_your_api_key",
  "transportMode": "agent_api_v1"
}
```

## Install for use

```bash
openclaw plugins install ./plugins/thinkly
openclaw plugins enable thinkly
openclaw gateway restart
```

## Export a distributable bundle

From the repo root:

```bash
npm run openclaw:export
```

This creates:

- `build/openclaw/thinkly-openclaw-plugin`
- `build/openclaw/thinkly-openclaw-plugin.tgz`

You can install the exported directory directly:

```bash
openclaw plugins install ./build/openclaw/thinkly-openclaw-plugin
openclaw plugins enable thinkly
openclaw gateway restart
```

## Install from GitHub Release

The current public distribution surface should be a GitHub Release asset in a public repo, not a private monorepo release.

```bash
openclaw plugins install https://github.com/pluglabai/thinkly-openclaw-plugin/releases/download/openclaw-plugin-v0.1.2/thinkly-openclaw-plugin.tgz
openclaw plugins enable thinkly
openclaw gateway restart
```

## Install from npm

```bash
openclaw plugins install @pluglab_thinkly/thinkly-openclaw-plugin
openclaw plugins enable thinkly
openclaw gateway restart
```

See also:

- `docs/openclaw-plugin-github-release-runbook-2026-04-11.md`
- `docs/openclaw-plugin-npm-package-transition-plan-2026-04-11.md`
- `docs/pluglab-public-distribution-plan-2026-04-11.md`

Public repo surfaces:

- Hub: `https://github.com/pluglabai/thinkly`
- OpenClaw repo: `https://github.com/pluglabai/thinkly-openclaw-plugin`
- Org profile: `https://github.com/pluglabai/.github`

## Assemble npm package artifact

For npm-package transition testing:

```bash
npm run openclaw:pack
```

This creates:

- `dist/openclaw-package/package`
- `dist/openclaw-package/package/thinkly-openclaw-plugin-<version>.tgz`

## Prepare a public distribution repo scaffold

```bash
npm run openclaw:prepare-public-repo
```

This creates:

- `dist/public-repos/thinkly-openclaw-plugin`

The public repo scaffold contains:

- npm publish source files
- GitHub Actions workflow for npm publish
- fallback GitHub Release assets under `release-assets/`

## Install for local development

Use a linked install so changes in this repo are reflected without copying files:

```bash
openclaw plugins install -l ./plugins/thinkly
openclaw plugins enable thinkly
openclaw gateway restart
```

Inspect the installed plugin and bundled skill:

```bash
openclaw plugins inspect thinkly
openclaw skills list
```

## Bundled skill

This plugin now ships a bundled OpenClaw skill under `skills/thinkly_capture/SKILL.md`.

The bundled skill teaches the agent when to use:

- `/clip`
- `/clip "text"`
- `/ingest`
- `/ingest save`
- `/ingest cancel`

The skill is loaded through the `skills` field in `openclaw.plugin.json`, which matches the native OpenClaw plugin manifest flow.

## Product framing

This plugin follows the Thinkly `ai-workflow` landing message:

- dump AI chats, notes, files, and links once
- let Thinkly organize them automatically
- reuse them later as pages, briefs, and connected knowledge

## Backward compatibility

`apiToken` is still supported as a fallback for older setups, but new installs should use `apiKey`.

`transportMode` defaults to `legacy_highlights`.

- `legacy_highlights`: full compatibility with current OpenClaw metadata flow
- `agent_api_v1`: experimental path that uses Thinkly Agent API for clip and ingest, while preserving OpenClaw provenance fields and duplicate checks

## Development notes

- `openclaw.plugin.json` is the native plugin manifest used for pre-runtime config validation.
- The plugin also ships a bundled skill root so OpenClaw can load Thinkly usage instructions directly from the plugin.
- For now, the runtime transport still targets Thinkly's legacy highlight endpoint to preserve existing OpenClaw capture metadata behavior.
- `npm run openclaw:export` is the current bridge from this private monorepo plugin to a distributable plugin bundle.
